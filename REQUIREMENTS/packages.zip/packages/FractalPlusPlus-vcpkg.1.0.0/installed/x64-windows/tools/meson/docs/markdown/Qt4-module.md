# Qt4 module

This module provides support for Qt4's `moc`, `uic` and `rcc`
tools. It is used identically to the [Qt 5 module](Qt5-module.md).

{{ _include_qt_base.md }}
