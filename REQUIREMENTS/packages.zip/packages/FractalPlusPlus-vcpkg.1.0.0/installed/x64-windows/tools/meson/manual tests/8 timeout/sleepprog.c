#include<unistd.h>

int main(void) {
    sleep(1000);
    return 0;
}
